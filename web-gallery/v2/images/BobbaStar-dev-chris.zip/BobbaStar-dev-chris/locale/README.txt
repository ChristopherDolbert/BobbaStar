These are the locale files used by HoloCMS as of 30th of January 2008 (5:35pm GMT+1).

If you want to translate - go ahead. Translations will be included in the release, and
of course, you will get full credit for your translation.

Questions?
E-Mail me at meth0d@retroscripting.com


Thanks in advance
~ Meth0d / GraphiX