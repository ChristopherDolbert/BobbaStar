<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

$locale['maintenance'] = "Maintenance";
$locale['maintenance_frank'] = "I think you hit the wrong switch, Greggers! All of ".$shortname." just vanished!";
$locale['maintenance_greggers'] = "Oh, calm down Frank. Sparky and I are just in the process of fixing something in ".$shortname." and had to take the website down while we work. We will return soon so check back in a little while.";

?>