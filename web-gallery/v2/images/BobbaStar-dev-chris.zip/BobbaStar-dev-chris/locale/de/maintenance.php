<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

$locale['maintenance'] = "Wartungsarbeiten";
$locale['maintenance_frank'] = "Oh nein! Benny, ".$shortname." wurde zerst�rt!";
$locale['maintenance_greggers'] = "Ach was! Beruhig dich, Frank! Wir renovieren gerade etwas und m�ssen deswegen den normalen Betrieb f�r eine Weile unterbrechen. Bald wird alles wieder normal funktionieren, drum nimm dir nen Keks und komm sp�ter nochmal vorbei.";

?>