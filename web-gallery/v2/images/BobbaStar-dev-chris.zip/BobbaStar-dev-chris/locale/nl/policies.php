<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

// Disclaimer / Terms of Service
$locale['terms_of_service_title'] = "Algemene voorwaarden";
$locale['terms_of_service'] = "De Algemene Voorwaarden zijn nog niet beschikbaar.";

// Privacy Policy
$locale['privacy_policy_title'] = "Privacyverklaring";
$locale['privacy_policy'] = "De Privacyverklaring is nog niet beschikbaar.";

?>