<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

$locale['maintenance'] = "Maintenance";
$locale['maintenance_frank'] = "Help ".$shortname." is verdwenen!";
$locale['maintenance_greggers'] = "Oh, relax nou eens Frank. We zijn op dit moment bezig met onderhoud aan ".shortname." en daarvoor is de site even niet beschikbaar. We hopen er snel weer te zijn, dus pak even wat te drinken en kom zo nog eens terug!";

?>