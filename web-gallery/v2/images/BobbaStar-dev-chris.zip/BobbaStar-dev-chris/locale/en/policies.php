<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright � 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

// Disclaimer / Terms of Service
$locale['terms_of_service_title'] = "Terms of Service";

// Privacy Policy
$locale['privacy_policy_title'] = "Informations pratiques";

