<?php
/*---------------------------------------------------+
| HoloCMS - Website and Content Management System
+----------------------------------------------------+
| Copyright &copy; 2008 Meth0d
+----------------------------------------------------+
| HoloCMS is provided "as is" and comes without
| warrenty of any kind. 
+---------------------------------------------------*/

$locale['maintenance'] = "Maintenance";
$locale['maintenance_frank'] = "Oh non! ".$shortname." a disparu!";
$locale['maintenance_greggers'] = "Du calme Francky! On r&eacute;pare l'h&ocirc;tel! Reviens dans quelques minutes.";

?>