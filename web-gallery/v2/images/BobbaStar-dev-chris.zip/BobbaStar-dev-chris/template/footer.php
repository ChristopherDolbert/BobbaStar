<?PHP
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|         Copyright © 2014-2023 - MyHabbo Tout droits réservés.          #|
#|																		  #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
?>
<div id="footer">
	<p><a href="<?PHP echo $url; ?>" target="_self">Accueil</a> | <a href="<?PHP echo $url; ?>/disclaimer" target="_self">Conditions Générales d'Utilisations</a> | <a href="<?PHP echo $url; ?>/infos" target="_self">Infos CMS</a>
	<p class="copyright">
		<?PHP echo $sitename; ?> est un projet indépendant, &agrave; but non lucratif &copy; 2012-2014.<br />
		Habbo est une marque déposée de Sulake Corporation. Tous droits réservés &agrave; leur(s) propriétaire(s) respectif(s).<br />Nous ne sommes pas approuvés, affiliés ou offertes par Sulake Corporation LTD.<br><br><u>&copy; <?PHP echo $version ?></u><br><br>
	</p>
</div>