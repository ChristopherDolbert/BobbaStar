<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Habbowood</title>
	<script src="https://unpkg.com/@ruffle-rs/ruffle"></script>
	<script>
		window.RufflePlayer = window.RufflePlayer || {};
		window.RufflePlayer.config = {
			// Start playing the content automatically, without audio if the browser in use does not allow audio to autoplay
			"autoplay": "on",
			// Do not show an overlay to unmute the content while it plays; when the content area receives its first interaction, it will unmute
			"unmuteOverlay": "hidden",
			// Do not show a splash screen before the content loads; the content area will remain blank until Ruffle fully loads the content
			"splashScreen": false,
		}
	</script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Habbo, Habbo Hotel, Habbo World, Sulake" />
	<meta name="description" content="In Habbo Hotel, real people create characters to have authentic conversations, play games, enter competitions, and develop new friendships." />
	<link rel="stylesheet" type="text/css" href="../css/style.css<?php echo '?'.mt_rand(); ?>" />
	<link rel="stylesheet" type="text/css" media="print" href="../css/print.css<?php echo '?'.mt_rand(); ?>" />
	<!-- .css<?php echo '?'.mt_rand(); ?> fixes for Mac IE -->
	<style type="text/css">
		@import_url("css/macie5.css<?php echo '?'.mt_rand(); ?>");
	</style>
	<!-- .css<?php echo '?'.mt_rand(); ?> fixes for IE 5.0 -->
	<style type="text/css">
		\@import url("css/ie5.css<?php echo '?'.mt_rand(); ?>");
	</style>
	<script type="text/javascript" src="js/flashobject.js"></script>
</head>

<body bgcolor="#292929" rightmargin=0"" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="100%" height="100%" valign="top" id="flashcontent">

				<div style="margin:20px;padding:20px;background-color:#FFFFFF;">
					<h2>Foutmelding!</h2>
					<p>Installeer eerst <a href="http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash&amp;promoid=BIOX">Flash</a>.</p>
					<p><a href="http://www.macromedia.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash&amp;promoid=BIOX"><img src="images/get_flash_player.gif" alt="Please install Flash Player" width="88" height="31" border="0" /></a></p>
				</div>

			</td>
			<td width="1"><img src="images/inviso.gif" width="1" height="770"></td>
		</tr>
		<tr>
			<td style="font-size:1px; height:1px;"><img src="images/inviso.gif" width="950" height="1"></td>
			<td><img src="images/inviso.gif" width="1" height="1"></td>
		</tr>
	</table>
	<script type="text/javascript">
		// <![CDATA[ 
		var fo = new FlashObject("../main.swf", "fotester", "100%", "100%", "7", "#292929");
		fo.addParam("allowScriptAccess", "sameDomain");
		fo.addParam("scale", "noscale");
		fo.addParam("name", "editor");
		fo.addParam("quality", "low");
		fo.addVariable("language", "nl");
		fo.addVariable("base", "../");

		fo.addVariable("welcomeLink_0", "http://www.habbohotel.nl/habbo/nl/community/habbowood/");
		fo.addVariable("welcomeLink_1", "http://www.habbohotel.nl/habbo/nl/community/habbowood/guerrilla");
		fo.addVariable("welcomeLink_2", "http://www.habbohotel.nl/habbo/nl/community/habbowood/gala/");
		fo.addVariable("welcomeLink_3", "http://www.habbohotel.nl/habbo/nl/community/habbowood/rules/");

		fo.addVariable("introType", "0");
		fo.addVariable("voteOn", "");
		fo.addVariable("hotelLink", "http%3A%2F%2Fwww.habbohotel.nl%2Fhabbo%2Fnl%2Fcommon%2Fexternal%2Fpartner_registration%3Fisp%3Dminisite%26partner%3Dhabbowood2");
		fo.addVariable("view", "0");


		fo.write("flashcontent");
		// ]]>
	</script>

	<!-- RedMeasure Starts instguide 2.10 -->
	<script language="JavaScript" type="text/javascript">
		<!--
		var pCid = "fi_Habbohotel_0";
		var pUrl = "http://www.habbohotel.nl/habbowood2.html";
		var w0 = 1;
		var refR = escape(document.referrer);
		if (refR.length >= 252) refR = refR.substring(0, 252) + "...";
		//
		-->
	</script>
	<script language="JavaScript1.1" type="text/javascript">
		<!-- 
		var w0 = 0;
		var rsUA = navigator.appName + " " + navigator.appVersion;
		var rsRUA = navigator.userAgent;
		var rsWS = window.screen;
		var rsBV = navigator.appVersion.substring(0, 1);
		var rsNN = (rsUA.indexOf('Netscape'));
		var rsMC = (rsUA.indexOf('Mac'));
		var rsIE = (rsUA.indexOf('MSIE'));
		var rsXP = (rsUA.indexOf('NT 5.1'));
		var rsCE = (rsUA.indexOf('Windows CE'));
		var rsLX = (rsUA.indexOf('Linux'));
		var rsOP = (rsRUA.indexOf('Opera'));
		var rsIEV = (parseInt(rsUA.substr(rsIE + 5)));
		var rsMSIE = false;
		var rsIE6 = false;
		var rsOSXP = false;
		var rsIE6XP = false;
		var rsSW = "na";
		var rsSH = "na";
		var rsCD = "na";
		var rsSR = "na";
		var
			rsLG = "na";
		var rsCT = "na";
		var rsHP = "na";
		var rsCK = "na";
		var rsJE = "na";
		var rsJE = (navigator.javaEnabled() == true) ? "y" : "n";
		if ((rsIE > 0) || ((rsNN != -1) && (rsBV >= 5))) {
			var rsCK = (navigator.cookieEnabled == true) ? "y" : "n";
		}
		if ((rsIE >= 0) && (rsIEV >= 5) && (rsMC == -1) && (rsOP == -1)) {
			document.body.addBehavior("#default#clientCaps");
			rsCT = document.body.connectionType;
			document.body.addBehavior("#default#homePage");
			rsHP = (document.body.isHomePage(location.href)) ? "y" : "n";
		}
		var rsD = new Date();
		var rsTZ = rsD.getTimezoneOffset() / -60;
		if ((typeof(rsWS) != "undefined") && (rsWS != null)) {
			rsSW = rsWS.width;
			rsSH = rsWS.height;
			rsCD = rsWS.colorDepth;
			if ((rsNN != -1) && (rsBV >= 4)) {
				rsCD = rsWS.pixelDepth;
			}
		}
		if ((rsNN != -1) && (rsBV >= 4) || (rsOP >= 0)) {
			var
				rsLG = navigator.language;
		}
		if ((rsIE != -1) && (rsBV >= 4) && (rsOP == -1)) {
			var
				rsLG = navigator.userLanguage;
		}
		document.write('<img src="http://server-fi.imrworldwide.com/cgi-bin/count?url=' + pUrl + '&rnd=' + (new Date()).getTime() + '&cid=' + pCid + '&ref=' + refR + '&sr=sr' + rsSW + 'x' + rsSH + ':cd' + rsCD + ':lg' + rsLG + ':je' + rsJE + ':ck' + rsCK + ':tz' + rsTZ + ':ct' + rsCT + ':hp' + rsHP + '" width="1" height="1">');
		//
		-->
	</script>
	<script language="JavaScript" type="text/javascript">
		<!-- 
		if (w0) {
			document.write('<img src="http://server-fi.imrworldwide.com/cgi-bin/count?url=' + pUrl + '&ref=' +
				refR + '&cid=' + pCid + '" width="1" height="1">');
		}
		//
		-->
	</script>
	<noscript>
		<img src="http://server-fi.imrworldwide.com/cgi-bin/count?url=http://www.habbohotel.nl/habbowood2.html&cid=fi_Habbohotel_0" width="1" height="1">
	</noscript>
	<!-- RedMeasure Ends -->
</body>

</html>